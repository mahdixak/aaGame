package view;

import javafx.application.Application;
import javafx.stage.Stage;

public class PlayWithFriendPage extends Application {
    private String currentPlayer;


    @Override
    public void start(Stage primaryStage) throws Exception {

    }

}
