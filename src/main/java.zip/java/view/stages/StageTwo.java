package view.stages;

public class StageTwo {
}
